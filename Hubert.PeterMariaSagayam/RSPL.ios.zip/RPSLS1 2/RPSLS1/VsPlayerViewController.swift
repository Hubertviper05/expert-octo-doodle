//
//  VsPlayerViewController.swift
//  RPSLS1
//
//  Created by Hubert Peter Maria Sagayam on 1/06/2015.
//  Copyright (c) 2015 Hubert Peter Maria Sagayam. All rights reserved.
//

import UIKit

class VsPlayerViewController: UIViewController {
    
    var rock: UIImage = UIImage(named: "rock.png")!;
    var paper: UIImage = UIImage(named: "paper.png")!;
    var scissors: UIImage = UIImage(named: "scissors.png")!;
    var lizard: UIImage = UIImage(named: "lizard.png")!;
    var spock: UIImage = UIImage(named: "spock.png")!;
    var defaultImage: UIImage = UIImage(named: "question.png")!;
    

    @IBOutlet weak var player2: UIImageView!

    @IBOutlet weak var player1: UIImageView!
    
    @IBOutlet weak var result: UILabel!
    var isplayer1 = true
    var player1Choice:Int!
    var player2Choice:Int!
    
    var playLimit = 10
    
    var playCount = 0
    
    var player1WinCount = 0
    var player2WinCount = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        result.text = "Player 1"
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func Rock(sender: UIButton) {
        if(isplayer1 == true){
            player1.image = rock
            self.view.addSubview(player1);
            player1Choice = 0
            isplayer1 = false
            
            player2.image = defaultImage
            self.view.addSubview(player2);
        }else{
            player2.image = rock
            self.view.addSubview(player2);
            player2Choice = 0
            isplayer1 = true
            
            player1.image = defaultImage
            self.view.addSubview(player1);
            resultHandler()
        }
        
    }
    @IBAction func Paper(sender: UIButton) {
        if(isplayer1 == true){
            player1.image = paper
            self.view.addSubview(player1);
            player1Choice = 1
            isplayer1 = false
            
            player2.image = defaultImage
            self.view.addSubview(player2);
            
        }else{
            player2.image = paper
            self.view.addSubview(player2);
            player2Choice = 1
            isplayer1 = true
            
            player1.image = defaultImage
            self.view.addSubview(player1);
            resultHandler()
        }
    }
    @IBAction func Scissor(sender: UIButton) {
        if(isplayer1 == true){
            player1.image = scissors
            self.view.addSubview(player1);
            player1Choice = 2
            isplayer1 = false
            
            player2.image = defaultImage
            self.view.addSubview(player2);
            
        }else{
            player2.image = scissors
            self.view.addSubview(player2);
            player2Choice = 2
            isplayer1 = true
            
            player1.image = defaultImage
            self.view.addSubview(player1);
            resultHandler()
        }
    }
    @IBAction func Lizard(sender: UIButton) {
        if(isplayer1 == true){
            player1.image = lizard
            self.view.addSubview(player1);
            player1Choice = 3
            isplayer1 = false
            
            player2.image = defaultImage
            self.view.addSubview(player2);
            
        }else{
            player2.image = lizard
            self.view.addSubview(player2);
            player2Choice = 3
            isplayer1 = true
            
            player1.image = defaultImage
            self.view.addSubview(player1);
            resultHandler()
        }
    }
    
    @IBAction func Spock(sender: UIButton) {
        if(isplayer1 == true){
            player1.image = spock
            self.view.addSubview(player1);
            player1Choice = 2
            isplayer1 = false
            
            player2.image = defaultImage
            self.view.addSubview(player2);
            
        }else{
            player2.image = spock
            self.view.addSubview(player2);
            player2Choice = 2
            isplayer1 = true
            
            player1.image = defaultImage
            self.view.addSubview(player1);
            resultHandler()
        }
    }
    
    func resultHandler(){
        playCount++
        var isWinner:Bool!
        if (player1Choice == player2Choice) {
            result.text = "Result : Draw"
        } else {
            
            if(player1Choice == 0){
                if (player2Choice == 2 || player2Choice == 3) {
                    isWinner = true
                    player1WinCount++
                } else{
                    isWinner = false
                    player2WinCount++
                }
                
            }
            else if(player1Choice == 1){
                if (player2Choice == 0 || player2Choice == 4) {
                    isWinner = true
                    player1WinCount++
                } else{
                    isWinner = false
                    player2WinCount++
                }
                
            }
            else if(player1Choice == 2){
                if (player2Choice == 1 || player2Choice == 5) {
                    isWinner = true
                    player1WinCount++
                } else{
                    isWinner = false
                    player2WinCount++
                }
                
            }
            else if(player1Choice == 3){
                if (player2Choice == 4 || player2Choice == 1) {
                    isWinner = true
                    player1WinCount++
                } else{
                    isWinner = false
                    player2WinCount++
                }
                
            }
            else if(player1Choice == 4){
                if (player2Choice == 2 || player2Choice == 0) {
                    isWinner = true
                    player1WinCount++
                } else{
                    isWinner = false
                    player2WinCount++
                }
                
            }
            
            if(isWinner == true){
                result.text = "Result : Player 1 Won"
            }else{
                result.text = "Result : Player 2 Won"
            }
            
            if(playCount == playLimit){
                gameCompleted()
            }
            
        }
        
        
    }
    
    func gameCompleted(){
        
        var message = ""
        if(player1WinCount > player2WinCount){
            message = "Winner! Player 1 Won \(player1WinCount) out of \(playLimit)"
        }else{
            message = "Winner! Player 2 Won \(player2WinCount) out of \(playLimit)"
        }
        let alertController = UIAlertController(title: "Game Completed", message:
            message, preferredStyle: UIAlertControllerStyle.Alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: { (UIAlertAction) -> Void in
            let mainViewController = self.storyboard?.instantiateViewControllerWithIdentifier("MainView") as ViewController
            
            self.presentViewController(mainViewController, animated: true, completion: nil)
            
        }))
        
        
        
        self.presentViewController(alertController, animated: true, completion: nil)
    }


}
