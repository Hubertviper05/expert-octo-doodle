//
//  ViewController.swift
//  RPSLS1
//
//  Created by Hubert Peter Maria Sagayam on 1/06/2015.
//  Copyright (c) 2015 Hubert Peter Maria Sagayam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

