//
//  VSCPUViewController.swift
//  RPSLS1
//
//  Created by Hubert Peter Maria Sagayam on 1/06/2015.
//  Copyright (c) 2015 Hubert Peter Maria Sagayam. All rights reserved.
//

import UIKit

class VSCPUViewController: UIViewController {

    var rock: UIImage = UIImage(named: "rock.png")!;
    var paper: UIImage = UIImage(named: "paper.png")!;
    var scissors: UIImage = UIImage(named: "scissors.png")!;
    var lizard: UIImage = UIImage(named: "lizard.png")!;
    var spock: UIImage = UIImage(named: "spock.png")!;
    
    
    @IBOutlet weak var CpuImage: UIImageView!
    
    @IBOutlet weak var PlayerImage: UIImageView!
    
    @IBOutlet weak var Moves: UILabel!
    
    var playLimit = 10
    
    var playCount = 0
    
    var userWinCount = 0
    var cpuWinCount = 0
    
    var userChoice:Int!
    var cpuChoice:Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    @IBAction func Rock(sender: UIButton) {
        PlayerImage.image = rock
        self.view.addSubview(PlayerImage);
        userChoice = 0
        cpuChoiceHandler()
        
    }
    @IBAction func Paper(sender: UIButton) {
        PlayerImage.image = paper
        self.view.addSubview(PlayerImage);
        userChoice = 1
        cpuChoiceHandler()
    }
    @IBAction func Scissors(sender: UIButton) {
        PlayerImage.image = scissors
        self.view.addSubview(PlayerImage);
        userChoice = 2
        cpuChoiceHandler()
    }
    @IBAction func Spock(sender: UIButton) {
        PlayerImage.image = spock
        self.view.addSubview(PlayerImage);
        userChoice = 4
        cpuChoiceHandler()
    }
    @IBAction func Lizard(sender: UIButton) {
        PlayerImage.image = lizard
        self.view.addSubview(PlayerImage);
        userChoice = 3
        cpuChoiceHandler()
    }
    
    func cpuChoiceHandler(){
        var cpuRandomChoice = arc4random_uniform(5);
        playCount++
        if (cpuRandomChoice == 0) {
            CpuImage.image = rock
            self.view.addSubview(CpuImage);
            cpuChoice = 0
        } else if (cpuRandomChoice == 1) {
            CpuImage.image = paper
            self.view.addSubview(CpuImage);
            cpuChoice = 1
        } else if (cpuRandomChoice == 2) {
            CpuImage.image = scissors
            self.view.addSubview(CpuImage);
            cpuChoice = 2
        } else if (cpuRandomChoice == 3) {
            CpuImage.image = lizard
            self.view.addSubview(CpuImage);
            cpuChoice = 3
        } else if (cpuRandomChoice == 4) {
            CpuImage.image = spock
            self.view.addSubview(CpuImage);
            cpuChoice = 4
        }
        resultHandler()
    }
    
    func resultHandler(){
        var isWinner:Bool!
        if (userChoice == cpuChoice) {
            Moves.text = "Result : Draw"
        } else {
            
            if(userChoice == 0){
                if (cpuChoice == 2 || cpuChoice == 3) {
                    isWinner = true
                    userWinCount++
                } else{
                    isWinner = false
                    cpuWinCount++
                }
                
            }
            else if(userChoice == 1){
                if (cpuChoice == 0 || cpuChoice == 4) {
                    isWinner = true
                    userWinCount++
                } else{
                    isWinner = false
                    cpuWinCount++
                }
                
            }
            else if(userChoice == 2){
                if (cpuChoice == 1 || cpuChoice == 5) {
                    isWinner = true
                    userWinCount++
                } else{
                    isWinner = false
                    cpuWinCount++
                }
                
            }
            else if(userChoice == 3){
                if (cpuChoice == 4 || cpuChoice == 1) {
                    isWinner = true
                    userWinCount++
                } else{
                    isWinner = false
                    cpuWinCount++
                }
               
            }
            else if(userChoice == 4){
                if (cpuChoice == 2 || cpuChoice == 0) {
                    isWinner = true
                    userWinCount++
                } else{
                    isWinner = false
                    cpuWinCount++
                }
              
            }
            
                if(isWinner == true){
                    Moves.text = "Result : You Won"
                }else{
                    Moves.text = "Result : You Lost"
                }
            if(playCount == playLimit){
                gameCompleted()
            }
            
    }
        
}
    func gameCompleted(){
        
        var message = ""
        if(userWinCount > cpuWinCount){
            message = "Winner! You Won \(userWinCount) out of \(playLimit)"
        }else{
            message = "Looser! You lost \(playLimit - userWinCount) out of \(playLimit)"
        }
        let alertController = UIAlertController(title: "Game Completed", message:
            message, preferredStyle: UIAlertControllerStyle.Alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: { (UIAlertAction) -> Void in
            let mainViewController = self.storyboard?.instantiateViewControllerWithIdentifier("MainView") as ViewController
            
            self.presentViewController(mainViewController, animated: true, completion: nil)

        }))

        
        
        self.presentViewController(alertController, animated: true, completion: nil)
    }
}
